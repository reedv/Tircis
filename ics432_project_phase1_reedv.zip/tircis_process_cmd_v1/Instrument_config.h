#ifndef INSTRUMENT_CONFIG_H
#define INSTRUMENT_CONFIG_H

#define ns_inst 324
#define nl_inst 256


#endif // INSTRUMENT_CONFIG_H
